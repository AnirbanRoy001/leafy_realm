<div class="p-3 text-center" style="background-color: #005600; color: white;">
	<div id="contact_info">
	    <p style="font-size: 2em;">Contact Information</p>
	    <div class="contact-details">
            <p><strong>Phone:</strong> (+880) 1716334950</p>
            <p><strong>Email:</strong> group3@gmail.com</p>
            <p><strong>Address:</strong> CSE370 (Section-14), BRAC University, Dhaka, Bangladesh</p>
            <p><strong>Social Media:</strong> <img src="./images/facebook.jpg" alt="" style="width: 30px; height: 30px;"> <img src="./images/x.jpg" alt="" style="width: 30px; height: 30px;"> <img src="./images/instagram.jpg" alt="" style="width: 30px; height: 30px;"></p>
        </div>
	    <!-- Additional content -->
	</div>
	<br><br>
	<hr>
	<div>
		<div class="container" style="background-color: white; width: 85px; height: 60px;">
			<img src="./images/logo.png" alt="" style="width: 100%; height: 100%;">
		</div>
		<p class="mt-2">All rights reserved &copy; Designed by Group-3</p>
	</div>
</div>